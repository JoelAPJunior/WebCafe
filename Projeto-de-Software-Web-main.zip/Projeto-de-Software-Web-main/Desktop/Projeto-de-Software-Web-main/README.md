
<img width="721" height="411" alt="Captura de Tela 2025-11-13 às 12 00 11" src="https://github.com/user-attachments/assets/435b719a-30a4-41a0-823d-34cd06950971" />

<img width="606" height="508" alt="Captura de Tela 2025-11-13 às 12 04 08" src="https://github.com/user-attachments/assets/c32dcc4b-1a12-470f-9eb0-0e1f6be42559" />
