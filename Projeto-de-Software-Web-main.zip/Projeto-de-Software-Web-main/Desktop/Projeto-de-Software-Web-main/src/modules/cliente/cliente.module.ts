import { Module } from '@nestjs/common';
import { ClienteController } from './cliente.controller';
import { ClienteService } from './cliente.service';
import { clienteProviders } from './cliente.providers';
import { DatabaseModule } from '../../database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [ClienteController],
  providers: [...clienteProviders, ClienteService],
  exports: [...clienteProviders],
})
export class ClienteModule {}
