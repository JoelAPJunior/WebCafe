import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity('cliente')
export class Cliente {
  @PrimaryGeneratedColumn({ name: 'id_cli' })
  id: number;

  @Column({ name: 'nome_cli', type: 'varchar', length: 100 })
  nome: string;

  @Column({ name: 'cpf_cli', type: 'varchar', length: 15 })
  cpf: string;

  @Column({ name: 'email_cli', type: 'varchar', length: 150 })
  email: string;

  @Column({ name: 'tel_cli', type: 'varchar', length: 20, nullable: true })
  tel: string;

  @Column({ name: 'endereco_cli', type: 'varchar', length: 200, nullable: true })
  endereco: string;
}
