import { Body, Controller, Get, Post, Render, Req, Res } from '@nestjs/common';
import { Request, Response } from 'express';
import { ClienteService } from './cliente.service';
import { ClienteDto } from './cliente.dto';
import { validate } from '../../common/validator/generic.validator';

@Controller('/cliente')
export class ClienteController {
  constructor(private readonly clienteService: ClienteService) {}

  @Get()
  @Render('cliente/listagem-cliente')
  async listar() {
    const clientes = await this.clienteService.getAll();
    return {
      listaClientes: clientes,
    };
  }

  @Get('/novo')
  @Render('cliente/formulario-cliente')
  novo() {
    return {};
  }

  @Post('/novo/salvar')
  async salvar(
    @Body() dadosForm: any,
    @Req() req: Request,
    @Res() res: Response,
  ) {

    const resultado = await validate(ClienteDto, dadosForm);

    if (resultado.isError) {
      req.addFlash('error', resultado.getErrors);
      req.setOld(dadosForm);
      return res.redirect('/cliente/novo');
    }

    try {
      await this.clienteService.create(dadosForm);

      req.addFlash('success', 'Cliente cadastrado com sucesso!');
      return res.redirect('/cliente');
    } catch (erro) {
      req.addFlash('error', 'Erro ao cadastrar cliente');
      req.setOld(dadosForm);
      return res.redirect('/cliente/novo');
    }
  }
}
