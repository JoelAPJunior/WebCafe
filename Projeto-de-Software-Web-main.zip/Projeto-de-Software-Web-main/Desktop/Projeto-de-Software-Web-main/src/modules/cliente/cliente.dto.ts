import { IsEmail, IsNotEmpty, Length } from "class-validator";

export class ClienteDto {

    @IsNotEmpty({ message: "O nome é obrigatório." })
    nome: string;

    @Length(11, 15, { message: "O CPF deve ter entre 11 e 15 caracteres." })
    cpf: string;

    @IsEmail({}, { message: "E-mail inválido." })
    email: string;

    telefone?: string;

    endereco?: string;
}
