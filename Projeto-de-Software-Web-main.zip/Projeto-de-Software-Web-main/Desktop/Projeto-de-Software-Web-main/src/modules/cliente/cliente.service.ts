import { Inject, Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { Cliente } from './cliente.entity';

@Injectable()
export class ClienteService {
  constructor(
    @Inject('CLIENTE_REPOSITORY')
    private readonly clienteRepository: Repository<Cliente>,
  ) {}

  async getAll(): Promise<Cliente[]> {
    return this.clienteRepository.find();
  }

  async create(data: any): Promise<Cliente> {
    const cliente = this.clienteRepository.create({
      nome: data.nome,
      cpf: data.cpf,
      email: data.email,
      tel: data.tel,
      endereco: data.endereco,
    });

    return this.clienteRepository.save(cliente);
  }
}
