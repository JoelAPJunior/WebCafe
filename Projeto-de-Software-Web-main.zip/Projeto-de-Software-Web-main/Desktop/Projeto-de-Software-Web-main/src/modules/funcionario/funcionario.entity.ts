import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('funcionario')
export class Funcionario {
  @PrimaryGeneratedColumn({ name: 'id_fun' })
  id: number;

  @Column({ name: 'nome_fun', type: 'varchar', length: 100 })
  nome: string;

  @Column({ name: 'cpf_fun', type: 'varchar', length: 15 })
  cpf: string;

  @Column({ name: 'email_fun', type: 'varchar', length: 150 })
  email: string;

  @Column({ name: 'tel_fun', type: 'varchar', length: 20, nullable: true })
  tel: string;

  @Column({ name: 'funcao_fun', type: 'varchar', length: 100 })
  funcao: string;
}
