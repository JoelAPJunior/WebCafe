import { Module } from '@nestjs/common';
import { DatabaseModule } from '../../database/database.module';
import { FuncionarioController } from './funcionario.controller';
import { FuncionarioService } from './funcionario.services';
import { funcionarioProviders } from './funcionario.providers';

@Module({
  imports: [DatabaseModule],
  controllers: [FuncionarioController],
  providers: [...funcionarioProviders, FuncionarioService],
})
export class FuncionarioModule {}
