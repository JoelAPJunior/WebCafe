import { Body, Controller, Get, Post, Render, Req, Res } from '@nestjs/common';
import { FuncionarioService } from './funcionario.services';
import { Request, Response } from 'express';

@Controller('/funcionario')
export class FuncionarioController {
  constructor(private readonly funcionarioService: FuncionarioService) {}

  @Get()
  @Render('funcionario/listagem-funcionario')
  async listar() {
    const funcionarios = await this.funcionarioService.findAll();
    return { listaFuncionarios: funcionarios };
  }

  @Get('/novo')
  @Render('funcionario/formulario-funcionario')
  novo() {
    return {};
  }

  @Post('/novo/salvar')
  async salvar(
    @Body() dadosForm: any,
    @Req() req: Request,
    @Res() res: Response,
  ) {
    try {
      await this.funcionarioService.create(dadosForm);
      req.addFlash('success', 'Funcionário cadastrado com sucesso!');
      return res.redirect('/funcionario');
    } catch (erro) {
      req.addFlash('error', 'Erro ao cadastrar funcionário');
      req.setOld(dadosForm);
      return res.redirect('/funcionario/novo');
    }
  }
}
