import { Inject, Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { Funcionario } from './funcionario.entity';

@Injectable()
export class FuncionarioService {

  constructor(
    @Inject('FUNCIONARIO_REPOSITORY')
    private funcionarioRepository: Repository<Funcionario>,
  ) {}

  findAll() {
    return this.funcionarioRepository.find();
  }

  create(data: any) {
    const funcionario = this.funcionarioRepository.create(data);
    return this.funcionarioRepository.save(funcionario);
  }
}
