import { DataSource } from 'typeorm';
import { Funcionario } from './funcionario.entity';

export const funcionarioProviders = [
  {
    provide: 'FUNCIONARIO_REPOSITORY',
    useFactory: (dataSource: DataSource) =>
      dataSource.getRepository(Funcionario),
    inject: ['DATA_SOURCE'],
  },
];
