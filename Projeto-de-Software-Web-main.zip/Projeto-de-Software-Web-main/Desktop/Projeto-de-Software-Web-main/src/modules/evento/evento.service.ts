import { Inject, Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { Evento } from './evento.entity';

@Injectable()
export class EventoService {

  constructor(
    @Inject('EVENTO_REPOSITORY')
    private eventoRepository: Repository<Evento>,
  ) {}

  findAll() {
    return this.eventoRepository.find();
  }

  create(data: any) {
    const evento = this.eventoRepository.create(data);
    return this.eventoRepository.save(evento);
  }
}
