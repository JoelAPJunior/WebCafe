import { Module } from '@nestjs/common';
import { DatabaseModule } from '../../database/database.module';
import { EventoController } from './evento.controller';
import { EventoService } from './evento.service';
import { eventoProviders } from './evento.providers';

@Module({
  imports: [DatabaseModule],
  controllers: [EventoController],
  providers: [...eventoProviders, EventoService],
})
export class EventoModule {}
