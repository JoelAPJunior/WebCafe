import { Body, Controller, Get, Post, Render, Req, Res } from '@nestjs/common';
import { EventoService } from './evento.service';
import { Request, Response } from 'express';

@Controller('/evento')
export class EventoController {
  constructor(private readonly eventoService: EventoService) {}

  @Get()
  @Render('evento/listagem-evento')
  async listar() {
    const eventos = await this.eventoService.findAll();
    return { listaEventos: eventos };
  }

  @Get('/novo')
  @Render('evento/formulario-evento')
  novo() {
    return {};
  }

  @Post('/novo/salvar')
  async salvar(
    @Body() dadosForm: any,
    @Req() req: Request,
    @Res() res: Response,
  ) {
    try {
      await this.eventoService.create(dadosForm);
      req.addFlash('success', 'Evento cadastrado com sucesso!');
      return res.redirect('/evento');
    } catch (err) {
      req.addFlash('error', 'Erro ao cadastrar evento');
      req.setOld(dadosForm);
      return res.redirect('/evento/novo');
    }
  }
}
