import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity('evento')
export class Evento {
  @PrimaryGeneratedColumn({ name: 'id_eve' })
  id: number;

  @Column({ name: 'titulo_eve', type: 'varchar', length: 200 })
  titulo: string;

  @Column({ name: 'descricao_eve', type: 'text' })
  descricao: string;

  @Column({ name: 'data_eve', type: 'datetime' })
  data: Date;

  @Column({ name: 'vagas_eve', type: 'int' })
  vagas: number;
}
