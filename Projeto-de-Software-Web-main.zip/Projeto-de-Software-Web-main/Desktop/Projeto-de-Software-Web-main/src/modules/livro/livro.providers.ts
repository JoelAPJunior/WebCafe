import { DataSource } from 'typeorm';
import { Livro } from './livro.entity';

export const livroProviders = [
  {
    provide: 'LIVRO_REPOSITORY',
    useFactory: (dataSource: DataSource) =>
      dataSource.getRepository(Livro),
    inject: ['DATA_SOURCE'],
  },
];
