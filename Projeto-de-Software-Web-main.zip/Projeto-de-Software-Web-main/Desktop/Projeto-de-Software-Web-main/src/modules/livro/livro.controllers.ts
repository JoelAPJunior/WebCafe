import { Body, Controller, Get, Post, Render, Req, Res } from '@nestjs/common';
import { LivroService } from './livro.service';
import { Request, Response } from 'express';
import { LivroDto } from './livro.dto';
import { validate } from '../../common/validator/generic.validator';

@Controller('/livro')
export class LivroController {
  constructor(private readonly livroService: LivroService) {}

  @Get()
  @Render('livro/listagem-livro')
  async listar() {
    const livros = await this.livroService.getAll();
    return { listaLivros: livros };
  }

  @Get('/novo')
  @Render('livro/formulario-livro')
  novo() {
    return {};
  }

  @Post('/novo/salvar')
  async salvar(@Body() dadosForm, @Req() req: Request, @Res() res: Response) {
    const resultado = await validate(LivroDto, dadosForm);

    if (resultado.isError) {
      req.addFlash('error', resultado.getErrors);
      req.setOld(dadosForm);
      return res.redirect('/livro/novo');
    }

    try {
      await this.livroService.create(dadosForm);
      req.addFlash('success', 'Livro cadastrado com sucesso!');
      return res.redirect('/livro');
    } catch (err) {
      req.addFlash('error', 'Erro ao cadastrar livro');
      req.setOld(dadosForm);
      return res.redirect('/livro/novo');
    }
  }
}
