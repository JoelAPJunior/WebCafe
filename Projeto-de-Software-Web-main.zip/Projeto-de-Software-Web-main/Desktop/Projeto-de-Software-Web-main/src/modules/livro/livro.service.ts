import { Inject, Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { Livro } from './livro.entity';

@Injectable()
export class LivroService {
  constructor(
    @Inject('LIVRO_REPOSITORY')
    private readonly livroRepo: Repository<Livro>,
  ) {}

  getAll() {
    return this.livroRepo.find();
  }

  create(data: any) {
    const livro = this.livroRepo.create(data);
    return this.livroRepo.save(livro);
  }
}
