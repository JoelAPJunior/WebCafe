
import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity('livro')
export class Livro {
  @PrimaryGeneratedColumn()
  id_liv: number;

  @Column()
  titulo_liv: string;

  @Column()
  autor_liv: string;

  @Column()
  ano_liv: number;

  @Column()
  quantidade_liv: number;
}
