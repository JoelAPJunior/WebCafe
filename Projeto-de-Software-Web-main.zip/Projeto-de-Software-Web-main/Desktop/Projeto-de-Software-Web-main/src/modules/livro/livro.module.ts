import { Module } from '@nestjs/common';
import { LivroController } from './livro.controllers';
import { LivroService } from './livro.service';
import { livroProviders } from './livro.providers';
import { DatabaseModule } from '../../database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [LivroController],
  providers: [...livroProviders, LivroService],
  exports: [...livroProviders],
})
export class LivroModule {}
