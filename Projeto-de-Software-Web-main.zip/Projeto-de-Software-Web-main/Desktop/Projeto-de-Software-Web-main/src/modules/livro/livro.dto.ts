import { IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class LivroDto {
  @IsNotEmpty()
  @IsString()
  titulo_liv: string;

  @IsNotEmpty()
  @IsString()
  autor_liv: string;

  @IsNotEmpty()
  @IsNumber()
  ano_liv: number;

  @IsNotEmpty()
  @IsNumber()
  quantidade_liv: number;
}
