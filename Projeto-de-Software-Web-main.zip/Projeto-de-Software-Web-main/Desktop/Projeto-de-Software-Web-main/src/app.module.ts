import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { FuncionarioModule } from './modules/funcionario/funcionario.module';
import { DatabaseModule } from './database/database.module';
import { ClienteModule } from './modules/cliente/cliente.module';
import { LivroModule } from './modules/livro/livro.module';
import { EventoModule } from './modules/evento/evento.module';

@Module({
  imports: [
    DatabaseModule,
    ClienteModule,
    LivroModule,
    EventoModule,
    FuncionarioModule
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
