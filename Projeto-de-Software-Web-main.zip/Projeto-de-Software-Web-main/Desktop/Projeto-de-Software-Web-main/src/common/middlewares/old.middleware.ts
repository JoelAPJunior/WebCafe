import { Injectable, NestMiddleware } from '@nestjs/common';
import { NextFunction, Request, Response } from 'express';

@Injectable()
export class OldMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: NextFunction) {
    req.setOld = (old: any) => {
      if (!req.session) req.session = {} as any;
      req.session.old = old ?? {};
    };

    req.getOld = <T = any>(): T => {
      const data = (req.session && (req.session as any).old) || {};
      return data as T;
    };

    res.locals.old = req.getOld();

    req.session.old = null;

    next();
  }
}
