import { Request, Response, NextFunction } from 'express';

export function flashMiddleware(req: Request, res: Response, next: NextFunction) {
    req['addFlash'] = (type: string, message: any) => {
        if (!req.session.flash) {
            req.session.flash = {};
        }
        if (!req.session.flash[type]) {
            req.session.flash[type] = [];
        }
        req.session.flash[type].push(message);
    };

    req['getFlash'] = (type: string) => {
        if (!req.session.flash || !req.session.flash[type]) {
            return [];
        }
        const messages = req.session.flash[type];
        delete req.session.flash[type];
        return messages;
    };

    req['setOld'] = (data: any) => {
        req.session.old = data;
    };

    req['getOld'] = () => {
        const old = req.session.old || {};
        delete req.session.old;
        return old;
    };

    next();
}
