import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { NestExpressApplication } from '@nestjs/platform-express';
import { join } from 'path';
import * as exphbs from 'express-handlebars';
import * as session from 'express-session';
import { flashMiddleware } from './common/middlewares/flash.middleware';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);

  const viewsPath = join(__dirname, 'views');   
  const layoutsPath = join(viewsPath, '_layouts');
  const partialsPath = join(viewsPath, '_partials');

  app.engine(
    'hbs',
    exphbs.engine({
      extname: '.hbs',
      defaultLayout: 'main',
      layoutsDir: layoutsPath,
      partialsDir: partialsPath,
    }),
  );

  app.setViewEngine('hbs');
  app.setBaseViewsDir(viewsPath);
  app.useStaticAssets(join(__dirname, '..', 'public'));

  app.use(
    session({
      secret: 'my-secret',
      resave: false,
      saveUninitialized: false,
    }),
  );

  app.use(flashMiddleware);

  await app.listen(3333);
  console.log('Rodando em http://localhost:3333');
}

bootstrap();
