import { Controller, Get, Render } from '@nestjs/common';

@Controller()
export class AppController {

  @Get('/')
  @Render('home')
  home() {
    return { };
  }

  @Get('/sobre')
  @Render('sobre')
  sobre() {
    return { };
  }

}
