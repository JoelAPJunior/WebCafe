document.querySelectorAll('form[action*="DELETE"]').forEach(f=>f.addEventListener('submit',e=>{if(!confirm('Deseja excluir este registro?')) e.preventDefault()}));
