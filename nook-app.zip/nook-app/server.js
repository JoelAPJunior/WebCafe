const express = require('express');
const session = require('express-session');
const methodOverride = require('method-override');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 3000;
const dbDir = path.join(__dirname, 'db');
const uploadDir = path.join(__dirname, 'public', 'uploads');
fs.mkdirSync(dbDir, { recursive: true });
fs.mkdirSync(uploadDir, { recursive: true });
const db = new Database(path.join(dbDir, 'nook.sqlite'));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(methodOverride('_method'));
app.use(session({ secret: process.env.SESSION_SECRET || 'nook-secret-dev', resave: false, saveUninitialized: false }));

const storage = multer.diskStorage({ destination: uploadDir, filename: (_, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/[^a-z0-9.]/gi, '_')) });
const upload = multer({ storage });

function init() {
  db.exec(`
  CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'cliente');
  CREATE TABLE IF NOT EXISTS clientes (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, cpf TEXT, email TEXT, telefone TEXT, endereco TEXT);
  CREATE TABLE IF NOT EXISTS funcionarios (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, cpf TEXT, email TEXT, telefone TEXT, funcao TEXT);
  CREATE TABLE IF NOT EXISTS livros (id INTEGER PRIMARY KEY AUTOINCREMENT, titulo TEXT NOT NULL, autor TEXT NOT NULL, ano INTEGER, quantidade INTEGER DEFAULT 0, capa TEXT);
  CREATE TABLE IF NOT EXISTS eventos (id INTEGER PRIMARY KEY AUTOINCREMENT, titulo TEXT NOT NULL, descricao TEXT, data TEXT, horario TEXT, local TEXT, vagas INTEGER DEFAULT 0, banner TEXT);
  CREATE TABLE IF NOT EXISTS reservas (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, livro_id INTEGER, data_reserva TEXT DEFAULT CURRENT_TIMESTAMP, status TEXT DEFAULT 'pendente', UNIQUE(user_id, livro_id));
  CREATE TABLE IF NOT EXISTS participacoes (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, evento_id INTEGER, data_registro TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(user_id, evento_id));
  `);
  const count = db.prepare('SELECT COUNT(*) c FROM users').get().c;
  if (!count) {
    const hash = bcrypt.hashSync('admin123', 10);
    db.prepare('INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)').run('Administrador Nook', 'admin@nook.com', hash, 'admin');
    db.prepare('INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)').run('Cliente Demo', 'cliente@nook.com', bcrypt.hashSync('cliente123',10), 'cliente');
    db.prepare('INSERT INTO livros (titulo,autor,ano,quantidade,capa) VALUES (?,?,?,?,?)').run('Memórias Póstumas de Brás Cubas','Machado de Assis',1881,4,'');
    db.prepare('INSERT INTO livros (titulo,autor,ano,quantidade,capa) VALUES (?,?,?,?,?)').run('A Hora da Estrela','Clarice Lispector',1977,3,'');
    db.prepare('INSERT INTO eventos (titulo,descricao,data,horario,local,vagas,banner) VALUES (?,?,?,?,?,?,?)').run('Clube de Leitura','Encontro mensal para leitores da comunidade.', '2026-07-12','19:00','Nook Cafeteria e Sebo',25,'');
    db.prepare('INSERT INTO eventos (titulo,descricao,data,horario,local,vagas,banner) VALUES (?,?,?,?,?,?,?)').run('Feira de Troca de Livros','Traga um livro e leve novas histórias para casa.', '2026-07-20','16:00','Área externa da Nook',40,'');
  }
}
init();

app.use((req,res,next)=>{ res.locals.user = req.session.user; res.locals.flash = req.session.flash; delete req.session.flash; next(); });
const flash = (req,msg,type='ok') => req.session.flash = { msg, type };
const adminOnly = (req,res,next)=> req.session.user?.role === 'admin' ? next() : res.redirect('/login');
const logged = (req,res,next)=> req.session.user ? next() : res.redirect('/login');
const imgPath = f => f ? '/uploads/'+f : '';

app.get('/', (req,res)=> {
  const livros = db.prepare('SELECT * FROM livros ORDER BY id DESC LIMIT 6').all();
  const eventos = db.prepare('SELECT * FROM eventos ORDER BY data ASC LIMIT 6').all();
  res.render('home', { livros, eventos });
});
app.get('/login', (req,res)=>res.render('login'));
app.post('/login', (req,res)=>{
  const u = db.prepare('SELECT * FROM users WHERE email=?').get(req.body.email);
  if(!u || !bcrypt.compareSync(req.body.password, u.password)){ flash(req,'Usuário ou senha inválidos.','error'); return res.redirect('/login'); }
  req.session.user = { id:u.id, name:u.name, email:u.email, role:u.role};
  res.redirect(u.role === 'admin' ? '/admin' : '/catalogo');
});
app.post('/logout',(req,res)=> req.session.destroy(()=>res.redirect('/')));

app.get('/catalogo',(req,res)=>{ const q=req.query.q||''; const livros=db.prepare(`SELECT * FROM livros WHERE titulo LIKE ? OR autor LIKE ? ORDER BY titulo`).all(`%${q}%`,`%${q}%`); res.render('catalogo',{livros,q}); });
app.post('/reservas/:id', logged, (req,res)=>{
  const livro = db.prepare('SELECT * FROM livros WHERE id=?').get(req.params.id);
  if(!livro || livro.quantidade < 1){ flash(req,'Livro indisponível.','error'); return res.redirect('/catalogo'); }
  try { db.prepare('INSERT INTO reservas (user_id, livro_id) VALUES (?,?)').run(req.session.user.id, req.params.id); db.prepare('UPDATE livros SET quantidade=quantidade-1 WHERE id=?').run(req.params.id); flash(req,'Reserva realizada com sucesso.'); }
  catch { flash(req,'Você já reservou este livro.','error'); }
  res.redirect('/minhas-reservas');
});
app.get('/minhas-reservas', logged, (req,res)=>{ const reservas=db.prepare(`SELECT r.*, l.titulo, l.autor FROM reservas r JOIN livros l ON l.id=r.livro_id WHERE r.user_id=? ORDER BY r.id DESC`).all(req.session.user.id); res.render('reservas',{reservas}); });
app.post('/reservas/:id/cancelar', logged, (req,res)=>{ const r=db.prepare('SELECT * FROM reservas WHERE id=? AND user_id=?').get(req.params.id, req.session.user.id); if(r && r.status==='pendente'){db.prepare('UPDATE reservas SET status="cancelada" WHERE id=?').run(r.id); db.prepare('UPDATE livros SET quantidade=quantidade+1 WHERE id=?').run(r.livro_id); flash(req,'Reserva cancelada.');} res.redirect('/minhas-reservas'); });

app.get('/eventos',(req,res)=>{ const eventos=db.prepare('SELECT * FROM eventos ORDER BY data ASC').all(); res.render('eventos',{eventos}); });
app.post('/eventos/:id/participar', logged, (req,res)=>{
 const ev=db.prepare('SELECT e.*, (SELECT COUNT(*) FROM participacoes p WHERE p.evento_id=e.id) inscritos FROM eventos e WHERE id=?').get(req.params.id);
 if(!ev || ev.inscritos >= ev.vagas){ flash(req,'Evento sem vagas disponíveis.','error'); return res.redirect('/eventos'); }
 try{ db.prepare('INSERT INTO participacoes (user_id, evento_id) VALUES (?,?)').run(req.session.user.id, req.params.id); flash(req,'Participação registrada.'); } catch { flash(req,'Você já está inscrito neste evento.','error'); }
 res.redirect('/eventos');
});

app.get('/admin', adminOnly, (req,res)=>{ const stats={livros:db.prepare('SELECT COUNT(*) c FROM livros').get().c,eventos:db.prepare('SELECT COUNT(*) c FROM eventos').get().c,clientes:db.prepare('SELECT COUNT(*) c FROM clientes').get().c,reservas:db.prepare('SELECT COUNT(*) c FROM reservas').get().c}; res.render('admin/dashboard',{stats}); });
function crud(name, table, fields, uploadField){
 app.get(`/admin/${name}`, adminOnly, (req,res)=>{ const rows=db.prepare(`SELECT * FROM ${table} ORDER BY id DESC`).all(); res.render(`admin/list`,{name,table,fields,rows}); });
 app.get(`/admin/${name}/novo`, adminOnly, (req,res)=>res.render('admin/form',{name,fields,row:{},action:`/admin/${name}`,method:'POST'}));
 app.post(`/admin/${name}`, adminOnly, upload.single(uploadField||'image'), (req,res)=>{ const data=fields.map(f=> req.file&&f.name===uploadField ? req.file.filename : (req.body[f.name]||'')); db.prepare(`INSERT INTO ${table} (${fields.map(f=>f.name).join(',')}) VALUES (${fields.map(()=>'?').join(',')})`).run(...data); flash(req,'Cadastro salvo.'); res.redirect(`/admin/${name}`); });
 app.get(`/admin/${name}/:id/editar`, adminOnly, (req,res)=>{ const row=db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(req.params.id); res.render('admin/form',{name,fields,row,action:`/admin/${name}/${req.params.id}?_method=PUT`,method:'POST'}); });
 app.put(`/admin/${name}/:id`, adminOnly, upload.single(uploadField||'image'), (req,res)=>{ const current=db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(req.params.id); const data=fields.map(f=> req.file&&f.name===uploadField ? req.file.filename : (req.body[f.name] || current[f.name] || '')); db.prepare(`UPDATE ${table} SET ${fields.map(f=>f.name+'=?').join(',')} WHERE id=?`).run(...data, req.params.id); flash(req,'Registro atualizado.'); res.redirect(`/admin/${name}`); });
 app.delete(`/admin/${name}/:id`, adminOnly, (req,res)=>{ db.prepare(`DELETE FROM ${table} WHERE id=?`).run(req.params.id); flash(req,'Registro excluído.'); res.redirect(`/admin/${name}`); });
}
crud('livros','livros',[{name:'titulo',label:'Título'},{name:'autor',label:'Autor'},{name:'ano',label:'Ano',type:'number'},{name:'quantidade',label:'Quantidade',type:'number'},{name:'capa',label:'Capa',type:'file'}],'capa');
crud('eventos','eventos',[{name:'titulo',label:'Título'},{name:'descricao',label:'Descrição',type:'textarea'},{name:'data',label:'Data',type:'date'},{name:'horario',label:'Horário',type:'time'},{name:'local',label:'Local'},{name:'vagas',label:'Vagas',type:'number'},{name:'banner',label:'Banner',type:'file'}],'banner');
crud('clientes','clientes',[{name:'nome',label:'Nome'},{name:'cpf',label:'CPF'},{name:'email',label:'E-mail'},{name:'telefone',label:'Telefone'},{name:'endereco',label:'Endereço'}]);
crud('funcionarios','funcionarios',[{name:'nome',label:'Nome'},{name:'cpf',label:'CPF'},{name:'email',label:'E-mail'},{name:'telefone',label:'Telefone'},{name:'funcao',label:'Função'}]);

app.listen(PORT, ()=> console.log(`Nook rodando em http://localhost:${PORT}`));
