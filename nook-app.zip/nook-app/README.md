# Aplicação Web para Nook Cafeteria e Sebo

Sistema web completo para catálogo de livros, reserva online, eventos literários e painel administrativo.

## Funcionalidades

- Login e logout com sessão protegida
- Painel administrativo
- Cadastro, consulta, edição e exclusão de livros
- Cadastro, consulta, edição e exclusão de eventos
- Cadastro, consulta, edição e exclusão de clientes
- Cadastro, consulta, edição e exclusão de funcionários
- Upload de capa de livro e banner de evento
- Catálogo público com busca
- Reserva de livros com baixa automática no estoque
- Cancelamento de reserva com retorno ao estoque
- Registro de participação em evento com bloqueio de inscrição duplicada
- Bloqueio de evento sem vagas
- Interface responsiva e moderna

## Como rodar

1. Instale o Node.js.
2. Abra a pasta do projeto no terminal.
3. Rode:

```bash
npm install
npm start
```

4. Acesse:

```text
http://localhost:3000
```

## Usuários de teste

Administrador:

```text
E-mail: admin@nook.com
Senha: admin123
```

Cliente:

```text
E-mail: cliente@nook.com
Senha: cliente123
```

## Banco de dados

O projeto usa SQLite. O banco é criado automaticamente em `db/nook.sqlite` na primeira execução.
