# Nook Cafeteria e Sebo

Sistema web para uma cafeteria/sebo com catálogo de livros, reservas, eventos literários e painel administrativo.

## O que foi melhorado

- Interface redesenhada com visual mais editorial, moderno e menos genérico.
- Home com hero chamativo, métricas, card de evento e área de destaque.
- Catálogo com cards mais bonitos, busca e estados de estoque claros.
- Página de eventos em formato de agenda visual.
- Login, reservas e painel admin com layout mais polido.
- Menu responsivo para celular.
- Animações leves de entrada e interações em botões/cards.
- Melhor uso de HTML sem quebrar a lógica existente do sistema.

## Funcionalidades

- Login e logout com sessão protegida.
- Painel administrativo.
- CRUD de livros, eventos, clientes e funcionários.
- Upload de capa de livro e banner de evento.
- Catálogo público com busca.
- Reserva de livros com baixa automática no estoque.
- Cancelamento de reserva com retorno ao estoque.
- Inscrição em eventos com bloqueio de duplicidade.
- Bloqueio de evento sem vagas.
- Interface responsiva.

## Como rodar

Abra o terminal dentro da pasta `nook-app` e execute:

```bash
npm install
npm start
```

Para desenvolvimento com reinício automático:

```bash
npm run dev
```

O comando `npm start` já compila o TypeScript antes de abrir o servidor.

Depois acesse:

```text
http://localhost:3000
```

## Usuários de teste

Administrador:

```text
E-mail: admin@nook.com
Senha: admin123
```

Cliente:

```text
E-mail: cliente@nook.com
Senha: cliente123
```

## Banco de dados

O projeto usa SQLite. O banco é criado automaticamente em `db/nook.sqlite` na primeira execução.
